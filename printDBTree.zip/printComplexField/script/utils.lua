
local utils = {}

local db = {}

function utils.isHave(dbName)
    if db[dbName] then
        return  true
    end

    return false
end

function utils.readFileAll(args)
    local f = assert(io.open(args, "r"))
    local t = f:read("*all")
    f:close()
    return t
end

function utils.writeAtEnd(dbName, ...)
    local f = assert(io.open("script/output.lua", "a"))
    assert(... ~= nil, "wirte nil in file")
    f:write("--", dbName, "\r") 
    f:write(...)
    db[dbName] = true
    f:close()
end

function utils:getDbString(allText, dbName)
    local str = string.match(allText, dbName .. ":ctor.-end%s")
    assert(str ~= nil, dbName .. "is wrong, please check or tell author")
    local c, d = string.find(str, "--self")
    str = string.sub(str, c - 1, string.len(str) - 4)
    return str
end

function utils.clearOutPut()
    local f = assert(io.open("script/output.lua", "w"))
    f:write("")
    f:close()
end

function utils.getDbTable(str)
    str = string.gsub(str, "%s", "")
    str = string.gsub(str, "--self.%w+:", "-")
    str = string.sub(str, 2, string.len(str))
    str = str .. "-"
    local value = {}

    for w in string.gmatch(str, ".-%-") do
        w = string.gsub(w, "-", "")
        table.insert(value, w)
    end

    return value
end

function utils:recursionPrintDb(allText, value)
    for _, v in ipairs(value) do
        if global.isBasicType(v) then          
        else
            local index = global.isComplexType(v)

            if index then               
                global.comPlexMethod[index](allText, v)
            elseif self:getDbString(allText, v) then --非集合复杂情况 
                if not utils.isHave(v) then             
                    utils.outPutString(allText, v)
                end
            else
                print(v .. "is a not define type")
            end
        end
    end
end

function utils.outPutString(allText, args)
    if utils.isHave(args) then
        return
    end

    local text = utils:getDbString(allText, args)

    if text then
        --打印Db
        utils.writeAtEnd(args, text)
        --获取db的所有value
        local value = utils.getDbTable(text)
        --递归打印复杂db
        utils:recursionPrintDb(allText, value)
    end
end

return utils