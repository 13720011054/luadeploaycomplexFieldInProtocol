utils = require("script/utils")
global = require("script/global")
local fileName = "i3k_sbean.lua"

local function main(args)
    assert(args ~= nil, "dbname is nil, please edit run.bat by txt or notePad")
    --清楚输出文件
    utils.clearOutPut()
    --读取i3k_sbean.lua
    local allText = utils.readFileAll(fileName)
    assert(allText ~= "", "read i3k_sbean.lua failed")
    --打印db
    utils.outPutString(allText, args)
end

main(...)