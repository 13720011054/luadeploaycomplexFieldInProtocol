
local global = {}

basicValueType = {"int32", "int16", "int8", "string"}
complexType = {"map", "set", "vector"}

function global.isBasicType(value)
    for _, v in ipairs(basicValueType) do
        if v == value then
            return true
        end
    end

    return false
end

function global.isComplexType(value)
    for k, v in ipairs(complexType) do
        if string.match(value, "^" .. v .. "%[.*%]$") then
           return k
        end
    end

    return false
end

function global.mapAnalysis(allText, value)
    local str = string.match(value, ",(%w+)%]")
    if global.isBasicType(str) then
   
    else
        utils.outPutString(allText, str)
    end
end

function global.setAnalysis(allText, value)
    local str = string.match(value, "%[(%w+)%]")

    if global.isBasicType(str) then
   
    else
        utils.outPutString(allText, str)
    end
end

function global.vectorAnalysis(allText, value)
    local str = string.match(value, "%[(%w+)%]")

    if global.isBasicType(str) then
       
    else
        utils.outPutString(allText, str)
    end
end

global.comPlexMethod = 
{
    [1] = global.mapAnalysis,
    [2] = global.setAnalysis,
    [3] = global.vectorAnalysis,
}


return global